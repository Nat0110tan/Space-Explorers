package spaceexplorers.strategies;

import spaceexplorers.publicapi.*;

import javax.crypto.spec.IvParameterSpec;
import java.util.*;

public class StudentStrategy implements IStrategy {

    /**
     * Method where students can observe the state of the system and schedule events to be executed.
     *
     * @param planets          The current state of the system.
     * @param planetOperations Helper methods students can use to interact with the system.
     * @param eventsToExecute  Queue students will add to in order to schedule events.
     */
    @Override
    public void takeTurn(List<IPlanet> planets, IPlanetOperations planetOperations, Queue<IEvent> eventsToExecute) {
        // In every turn, calls helper method to separate conquered and unconquered planets
        // Attack decides to explore new planets by sending shuttles
        Helper helper = new Helper(planets,planetOperations,eventsToExecute);
        this.attack(helper,planets,planetOperations,eventsToExecute);
    }

    public void attack(Helper helper, List<IPlanet> planets, IPlanetOperations planetOperations, Queue<IEvent> eventsToExecute){
        for(IVisiblePlanet planet: helper.conqueredPlanets){
            // Uses two queues to store the source and target planets. The queues store planets when a sourcePlanet is near a
            // target planet. We then remove from these queues to call the appropriate eventsToExecute method.
            long people = planet.getTotalPopulation();

            Queue<IVisiblePlanet> sourcePlanets = new LinkedList<>();
            Queue<IVisiblePlanet> targetPlanets = new LinkedList<>();

            for(IEdge edge : planet.getEdges()){
                if(edge!=null && helper.unconqueredPlanets.containsKey(edge.getDestinationPlanetId())&&people>=2L){
                    IVisiblePlanet target = helper.unconqueredPlanets.get(edge.getDestinationPlanetId());
                    sourcePlanets.add(planet);
                    targetPlanets.add(target);
                    people--;
                }
            }

            while(!sourcePlanets.isEmpty()){
                IVisiblePlanet sourcePlanet = sourcePlanets.remove();
                IVisiblePlanet targetPlanet = targetPlanets.remove();
                eventsToExecute.add(planetOperations.transferPeople(sourcePlanet,targetPlanet,1L));
            }
        }
    }


    private class Helper{
        // Uses an ArrayList and a HashMap to store conquered and unconquered planets
        private List<IVisiblePlanet> conqueredPlanets = new ArrayList<>();
        private HashMap<Integer, IVisiblePlanet> unconqueredPlanets = new HashMap();

        public Helper(List<IPlanet> planets, IPlanetOperations planetOperations, Queue<IEvent> eventsToExecute){
            // We organize the status of each planet by looping through all planets in map and checking their owners
            planets.forEach((planetx) -> {
                if (planetx instanceof IVisiblePlanet) {
                    if (((IVisiblePlanet) planetx).getOwner() == Owner.SELF) {
                        conqueredPlanets.add((IVisiblePlanet) planetx);
                    } else {
                        unconqueredPlanets.put(planetx.getId(), (IVisiblePlanet) planetx);
                    }
                }
            });

        }
    }

    @Override
    public String getName() {
        return "Student";
    }

    @Override
    public boolean compete() {
        return false;
    }

}

