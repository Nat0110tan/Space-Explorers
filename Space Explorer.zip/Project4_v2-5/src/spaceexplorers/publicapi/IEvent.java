package spaceexplorers.publicapi;

public interface IEvent {
}
