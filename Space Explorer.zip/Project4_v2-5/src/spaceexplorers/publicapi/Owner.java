package spaceexplorers.publicapi;

public enum Owner {
    SELF,
    OPPONENT,
    NEUTRAL,
}
