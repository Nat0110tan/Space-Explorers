package spaceexplorers.publicapi;

public interface IEdge {
    int getSourcePlanetId();

    int getDestinationPlanetId();

    int getLength();
}
